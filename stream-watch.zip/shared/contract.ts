import { z } from "zod";

export const MIN_INTERVAL_MS = 30_000;
export const MAX_INTERVAL_MS = 86_400_000;
export const MAX_CHANNELS = 500;

export const HANDLE_RE = /^@[A-Za-z0-9._-]{3,30}$/;
export const VIDEO_ID_RE = /^[\w-]{11}$/;
export const CHANNEL_ID_RE = /^UC[\w-]{22}$/;
export const WEBHOOK_RE =
  /^https:\/\/(?:(?:canary|ptb)\.)?(?:discord|discordapp)\.com\/api(?:\/v\d+)?\/webhooks\/\d{15,25}\/[\w-]{20,}$/;

const PROXY_PROTOCOLS = new Set(["http:", "https:", "socks5:", "socks5h:"]);

export function isProxyUrl(value: string): boolean {
  try {
    const url = new URL(value);
    return PROXY_PROTOCOLS.has(url.protocol) && url.hostname !== "" && url.pathname.replace(/\/+$/, "") === "" && !url.search && !url.hash;
  } catch {
    return false;
  }
}

export const AUDIT_LEVELS = ["info", "warn", "error"] as const;
export type AuditLevel = (typeof AUDIT_LEVELS)[number];

export const uuid = z.uuid();
const name = z.string().trim().min(1, "Name is required").max(80, "Name is too long (max 80)");
const handle = z
  .string()
  .trim()
  .transform((s) => (s.startsWith("@") ? s : `@${s}`))
  .pipe(z.string().regex(HANDLE_RE, "Invalid YouTube handle (example: @channelname)"));
const webhookIds = z.array(uuid).max(25);
const proxyUrl = z
  .string()
  .trim()
  .max(300)
  .nullable()
  .transform((s) => s || null)
  .refine((s) => s === null || isProxyUrl(s), "Proxy must look like http://host:port or socks5://host:port");

export const schemas = {
  channelCreate: z.object({ handle, webhookIds: webhookIds.default([]) }),
  channelPatch: z.object({ enabled: z.boolean().optional(), webhookIds: webhookIds.optional() }),
  webhookCreate: z.object({ name, url: z.string().trim().regex(WEBHOOK_RE, "Invalid Discord webhook URL") }),
  webhookPatch: z.object({ enabled: z.boolean().optional(), name: name.optional() }),
  settings: z
    .object({
      intervalMs: z
        .int("Interval must be a whole number")
        .min(MIN_INTERVAL_MS, `Interval must be at least ${MIN_INTERVAL_MS / 1000} seconds`)
        .max(MAX_INTERVAL_MS, `Interval must be at most ${MAX_INTERVAL_MS / 3_600_000} hours`)
        .optional(),
      auto: z.boolean().optional(),
      proxyUrl: proxyUrl.optional(),
    })
    .refine((v) => Object.values(v).some((x) => x !== undefined), "Nothing to change"),
  auditQuery: z.object({
    level: z.enum(AUDIT_LEVELS).optional(),
    before: z.coerce.number().int().positive().optional(),
    limit: z.coerce.number().int().min(1).max(100).default(50),
  }),
};

export type ChannelCreateInput = z.input<typeof schemas.channelCreate>;
export type ChannelPatchInput = z.input<typeof schemas.channelPatch>;
export type WebhookCreateInput = z.input<typeof schemas.webhookCreate>;
export type WebhookPatchInput = z.input<typeof schemas.webhookPatch>;
export type SettingsInput = z.input<typeof schemas.settings>;

export type StreamStatus = "upcoming" | "live";
export type CheckSource = "rss" | "api";

export interface ChannelDto {
  id: string;
  handle: string;
  name: string | null;
  enabled: boolean;
  checkedAt: number | null; // unix seconds
  upcoming: number;
  live: number;
  source: CheckSource | null;
  error: string | null;
  webhookIds: string[];
}

export interface WebhookDto {
  id: string;
  name: string;
  preview: string; // never contains any part of the secret token
  enabled: boolean;
  error: string | null;
}

export interface RecentDto {
  webhookId: string;
  videoId: string;
  title: string;
  handle: string;
  webhook: string;
  status: StreamStatus;
  canResend: boolean;
  startAt: number | null; // unix seconds
  sentAt: number; // unix seconds
}

export interface CycleDto {
  auto: boolean;
  running: boolean;
  intervalMs: number;
  lastCycleAt: number | null; // unix milliseconds
  nextCycleAt: number | null; // unix milliseconds, null while auto checks are off
}

export interface SourcesDto {
  apiConfigured: boolean;
  proxy: { url: string; healthy: boolean; error: string | null } | null; // url never contains credentials
}

export interface Overview {
  /** Increases with every snapshot, so the dashboard can drop a stale one that arrives late. */
  rev: number;
  cycle: CycleDto;
  sources: SourcesDto;
  channels: ChannelDto[];
  webhooks: WebhookDto[];
  recent: RecentDto[];
}

export interface CheckSummary {
  channels: number;
  sent: number;
  failed: number;
}

export interface CheckDoneEvent extends CheckSummary {
  target: string;
}

export interface AuditDto {
  id: number;
  at: number; // unix milliseconds
  level: AuditLevel;
  kind: string;
  message: string;
}

export interface AuditPage {
  items: AuditDto[];
  nextBefore: number | null;
}

export interface StreamSentEvent {
  title: string;
  videoId: string;
  handle: string;
  webhookName: string;
  startAt: number | null;
  sentAt: number;
}

export interface ChannelErrorEvent {
  channelId: string;
  handle: string;
  error: string;
}

export type WsMessage =
  | { type: "overview"; data: Overview }
  | { type: "audit" }
  | { type: "stream_sent"; data: StreamSentEvent }
  | { type: "channel_error"; data: ChannelErrorEvent }
  | { type: "check_done"; data: CheckDoneEvent };
