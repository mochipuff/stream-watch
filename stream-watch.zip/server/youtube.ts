import { setTimeout as sleep } from "node:timers/promises";
import { z } from "zod";
import { CHANNEL_ID_RE } from "../shared/contract.ts";
import type { CheckSource, StreamStatus } from "../shared/contract.ts";
import { audit } from "./audit.ts";
import { YOUTUBE_API_KEY, errorMessage } from "./config.ts";
import { query } from "./db.ts";
import { ytFetch } from "./http.ts";

export interface Stream {
  videoId: string;
  title: string;
  status: StreamStatus;
  startAt: number | null; // unix seconds
}

export interface ChannelRef {
  handle: string;
  youtubeId: string | null;
  name: string | null;
}

export interface Lookup {
  channelId: string;
  channelName: string;
  source: CheckSource;
  streams: Stream[];
}

class NotFoundError extends Error {}

class HttpError extends Error {
  status: number;
  constructor(status: number) {
    super(`YouTube HTTP ${status}`);
    this.status = status;
  }
}

class ApiError extends Error {
  reason: string;
  constructor(status: number, reason: string) {
    super(`YouTube API ${status}${reason ? `: ${reason}` : ""}`);
    this.reason = reason;
  }
}

type Res = Awaited<ReturnType<typeof ytFetch>>;

const PAGE_HEADERS = {
  "user-agent":
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36",
  "accept-language": "en-US,en;q=0.9",
  cookie: "CONSENT=YES+1; SOCS=CAI",
};

const REQUEST_TIMEOUT_MS = 8000;
const MAX_FEED_BYTES = 512 * 1024;
const MAX_API_BYTES = 256 * 1024;
const MAX_CANDIDATES = 15;
// YouTube's feed endpoint has answered with short-lived 404/5xx errors for healthy channels, so one retry is worth it.
const FEED_RETRY_DELAY_MS = 1500;
// A channel page carries its channel id inside inline JSON that can sit 1-2.5 MB into the HTML.
const CHANNEL_PAGE_MAX_CHARS = 3_000_000;
// A new channel has many unclassified videos. Spreading them over several checks keeps the first cycle light.
const MAX_PAGE_LOOKUPS_PER_CHECK = 5;
const STREAM_TTL_MS = 5 * 60_000;
const PLAIN_TTL_SEC = 14 * 86_400;
const API_PAUSE_MS = 3_600_000;

const nowSec = () => Math.floor(Date.now() / 1000);
const toUnix = (iso: string | undefined) => {
  const sec = Math.floor(Date.parse(iso ?? "") / 1000);
  return Number.isFinite(sec) && sec > 0 ? sec : null;
};

// A video that is neither live nor upcoming never becomes one, so that answer is stored and never asked again.
const findPlain = query("SELECT 1 FROM plain_videos WHERE video_id = ?");
const savePlain = query("INSERT OR REPLACE INTO plain_videos (video_id, checked_at) VALUES (?, ?)");
query("DELETE FROM plain_videos WHERE checked_at < ?").run(nowSec() - PLAIN_TTL_SEC);

// Live and upcoming streams are re-read only every few minutes. Their status changes nothing about the one-time notification.
const streamMemo = new Map<string, { stream: Stream; until: number }>();

function remember(videoId: string, stream: Stream | null) {
  if (!stream) {
    streamMemo.delete(videoId);
    savePlain.run(videoId, nowSec());
    return;
  }
  if (streamMemo.size >= 200) streamMemo.delete(streamMemo.keys().next().value!);
  streamMemo.set(videoId, { stream, until: Date.now() + STREAM_TTL_MS });
}

function cached(videoId: string): { known: true; stream: Stream | null } | { known: false } {
  if (findPlain.get(videoId)) return { known: true, stream: null };
  const memo = streamMemo.get(videoId);
  return memo && memo.until > Date.now() ? { known: true, stream: memo.stream } : { known: false };
}

async function ensureOk(res: Res) {
  if (res.ok) return;
  await res.body?.cancel().catch(() => {});
  throw new HttpError(res.status);
}

async function readBounded(res: Res, maxBytes: number): Promise<string> {
  const decoder = new TextDecoder();
  let text = "";
  let bytes = 0;
  for await (const chunk of res.body ?? []) {
    bytes += chunk.length;
    if (bytes > maxBytes) throw new Error("YouTube response is too large");
    text += decoder.decode(chunk, { stream: true });
  }
  return text + decoder.decode();
}

// Streams the page and stops as soon as `isDone` accepts what has been read, so the rest of the (often 1 MB+) page is
// never downloaded. `isDone` runs once per chunk.
async function getHtml(url: string, isDone: (html: string) => boolean, maxChars = 4_000_000): Promise<string> {
  const res = await ytFetch(url, { headers: PAGE_HEADERS, redirect: "follow", timeoutMs: REQUEST_TIMEOUT_MS });
  await ensureOk(res);
  if (res.url.includes("consent.youtube.com")) {
    await res.body?.cancel().catch(() => {});
    throw new Error("YouTube consent page blocked the request");
  }
  const decoder = new TextDecoder();
  let html = "";
  for await (const chunk of res.body ?? []) {
    html += decoder.decode(chunk, { stream: true });
    if (isDone(html) || html.length > maxChars) break; // leaving the loop cancels the download
  }
  return html;
}

// Done once `end` follows `marker`. Each chunk is only searched from where the previous search stopped, so the cost stays linear.
function markerThenEnd(marker: string, end: string): (html: string) => boolean {
  let markerAt = -1;
  let scanned = 0;
  return (html) => {
    if (markerAt === -1) {
      markerAt = html.indexOf(marker, Math.max(0, scanned - marker.length));
      if (markerAt !== -1) scanned = markerAt;
    }
    if (markerAt !== -1 && html.indexOf(end, Math.max(markerAt, scanned - end.length)) !== -1) return true;
    scanned = html.length;
    return false;
  };
}

// Scans braces (string-aware) instead of looking for a fixed terminator: the player response is followed by more JS on the same line.
function extractJson(html: string, marker: string): unknown {
  const at = html.indexOf(marker);
  if (at === -1) return null;
  const open = html.indexOf("{", at + marker.length);
  if (open === -1) return null;
  let depth = 0;
  let inString = false;
  for (let i = open; i < html.length; i++) {
    const ch = html[i];
    if (inString) {
      if (ch === "\\") i++;
      else if (ch === '"') inString = false;
    } else if (ch === '"') inString = true;
    else if (ch === "{") depth++;
    else if (ch === "}" && --depth === 0) {
      try {
        return JSON.parse(html.slice(open, i + 1));
      } catch {
        return null;
      }
    }
  }
  return null;
}

// ---------- Source 1: RSS feed, classified through the watch page ----------

const PLAYER_MARKER = "ytInitialPlayerResponse = ";

// YouTube's page JSON is undocumented, so only the fields that are used are declared and all of them are optional.
const playerSchema = z.object({
  playabilityStatus: z.object({ status: z.string().optional() }).optional(),
  videoDetails: z.object({ videoId: z.string(), title: z.string().optional(), isUpcoming: z.boolean().optional() }).optional(),
  microformat: z
    .object({
      playerMicroformatRenderer: z
        .object({
          liveBroadcastDetails: z
            .object({ isLiveNow: z.boolean().optional(), startTimestamp: z.string().optional(), endTimestamp: z.string().optional() })
            .optional(),
        })
        .optional(),
    })
    .optional(),
});

function classifyPlayer(html: string, videoId: string): Stream | null {
  const parsed = playerSchema.safeParse(extractJson(html, PLAYER_MARKER));
  if (!parsed.success) throw new Error("YouTube page layout changed: player data is not readable");
  const { videoDetails: video, microformat, playabilityStatus } = parsed.data;
  const live = microformat?.playerMicroformatRenderer?.liveBroadcastDetails;
  if (video?.videoId !== videoId || !live || live.endTimestamp) return null;
  const title = video.title || "Untitled stream";
  const startAt = toUnix(live.startTimestamp);
  if (live.isLiveNow) return { videoId, title, status: "live", startAt };
  if (video.isUpcoming || playabilityStatus?.status === "LIVE_STREAM_OFFLINE") return { videoId, title, status: "upcoming", startAt };
  return null;
}

async function classifyByPages(videoIds: string[]): Promise<Stream[]> {
  const streams: Stream[] = [];
  const errors: unknown[] = [];
  let lookups = 0;
  for (const id of videoIds) {
    const hit = cached(id);
    if (hit.known) {
      if (hit.stream) streams.push(hit.stream);
      continue;
    }
    if (lookups === MAX_PAGE_LOOKUPS_PER_CHECK) break;
    lookups++;
    try {
      const stream = classifyPlayer(await getHtml(`https://www.youtube.com/watch?v=${id}`, markerThenEnd(PLAYER_MARKER, "</script>")), id);
      remember(id, stream);
      if (stream) streams.push(stream);
    } catch (err) {
      errors.push(err);
    }
  }
  // Every lookup failing means YouTube is refusing us, so the error is reported and the API fallback can take over.
  if (lookups > 0 && errors.length === lookups) throw errors[0];
  return streams;
}

// Places where a channel page names its own channel, most specific first. YouTube has moved the RSS link around before,
// so a single tag is not relied on. "channelId" is deliberately absent: it also appears for recommended channels.
const CHANNEL_ID_PATTERNS = [
  /feeds\/videos\.xml\?channel_id=(UC[\w-]{22})/,
  /<link rel="canonical" href="https:\/\/www\.youtube\.com\/channel\/(UC[\w-]{22})"/,
  /<meta property="og:url" content="https:\/\/www\.youtube\.com\/channel\/(UC[\w-]{22})"/,
  /\{"key":"browse_id","value":"(UC[\w-]{22})"/,
  /"externalId":"(UC[\w-]{22})"/,
  /<meta itemprop="(?:identifier|channelId)" content="(UC[\w-]{22})"/,
];
// "browseId" also names featured and related channels, so it never ends the download early and is only used when
// no pattern above matched anywhere in the page.
const BROWSE_ID_PATTERN = /"browseId":"(UC[\w-]{22})"/;
// Longer than the longest match above, so a match split across two chunks is still seen.
const CHANNEL_ID_OVERLAP = 128;

function readChannelId(html: string): string | null {
  for (const pattern of CHANNEL_ID_PATTERNS) {
    const id = pattern.exec(html)?.[1];
    if (id) return id;
  }
  return null;
}

// Each chunk is only searched from where the previous one ended, so the cost stays linear on a multi-MB page.
// Stateful: a new one is needed for every request.
function channelIdArrived(): (html: string) => boolean {
  let scanned = 0;
  return (html) => {
    const from = Math.max(0, scanned - CHANNEL_ID_OVERLAP);
    scanned = html.length;
    return readChannelId(from === 0 ? html : html.slice(from)) !== null;
  };
}

async function resolveChannelId(handle: string): Promise<string> {
  let html: string;
  try {
    html = await getHtml(`https://www.youtube.com/${handle}`, channelIdArrived(), CHANNEL_PAGE_MAX_CHARS);
  } catch (err) {
    if (err instanceof HttpError && err.status === 404) throw new NotFoundError("Channel not found");
    throw err;
  }
  const id = readChannelId(html);
  if (id) return id;
  // The main page is a different layout for some channels, so the about page gets one chance. Its failure is not the answer.
  const about = await getHtml(`https://www.youtube.com/${handle}/about`, channelIdArrived(), CHANNEL_PAGE_MAX_CHARS).catch(() => "");
  const found = readChannelId(about) ?? BROWSE_ID_PATTERN.exec(html)?.[1] ?? BROWSE_ID_PATTERN.exec(about)?.[1];
  if (found) return found;
  const title = /<title>([^<]{1,80})/.exec(html)?.[1]?.trim();
  throw new Error(`Could not read the channel id from YouTube${title ? ` (page title: ${title})` : ""}`);
}

const XML_ENTITIES: Record<string, string> = { amp: "&", lt: "<", gt: ">", quot: '"', apos: "'" };
const decodeXml = (text: string) =>
  text.replace(/&(#x[0-9a-f]+|#\d+|amp|lt|gt|quot|apos);/gi, (whole, entity: string) => {
    if (entity.startsWith("#")) {
      const code = entity[1]?.toLowerCase() === "x" ? parseInt(entity.slice(2), 16) : Number(entity.slice(1));
      return Number.isInteger(code) && code > 0 && code <= 0x10ffff ? String.fromCodePoint(code) : whole;
    }
    return XML_ENTITIES[entity.toLowerCase()] ?? whole;
  });

async function fetchFeed(param: string): Promise<{ channelName: string | null; videoIds: string[] }> {
  const res = await ytFetch(`https://www.youtube.com/feeds/videos.xml?${param}`, {
    headers: { "user-agent": PAGE_HEADERS["user-agent"] },
    timeoutMs: REQUEST_TIMEOUT_MS,
  });
  await ensureOk(res);
  const xml = await readBounded(res, MAX_FEED_BYTES);
  if (!xml.includes("<feed")) throw new Error("YouTube feed was not readable");
  return {
    channelName: decodeXml(/<author>\s*<name>([^<]*)<\/name>/.exec(xml)?.[1] ?? "").trim() || null,
    videoIds: [...xml.matchAll(/<yt:videoId>([\w-]{11})<\/yt:videoId>/g)].map((m) => m[1]!).slice(0, MAX_CANDIDATES),
  };
}

// 429 is deliberately not transient: retrying a rate limit only makes it worse, and the API fallback should take over.
const isTransient = (err: unknown) => err instanceof HttpError && (err.status === 404 || err.status >= 500);

// Channel feed, one retry on a transient error, then the channel's live-streams playlist feed (UULV + id without "UC").
// The playlist feed has the same format and needs no key. When it fails too, the channel feed's error is the one reported.
async function readFeed(channelId: string): Promise<{ channelName: string | null; videoIds: string[] }> {
  const channelFeed = `channel_id=${channelId}`;
  try {
    return await fetchFeed(channelFeed);
  } catch (first) {
    if (!isTransient(first)) throw first;
    await sleep(FEED_RETRY_DELAY_MS);
    try {
      return await fetchFeed(channelFeed);
    } catch (second) {
      if (!isTransient(second)) throw second;
      return await fetchFeed(`playlist_id=UULV${channelId.slice(2)}`).catch(() => {
        throw second;
      });
    }
  }
}

async function viaRss(channel: ChannelRef): Promise<Lookup> {
  const channelId = channel.youtubeId ?? (await resolveChannelId(channel.handle));
  const feed = await readFeed(channelId);
  return {
    channelId,
    channelName: feed.channelName ?? channel.name ?? channel.handle,
    source: "rss",
    streams: await classifyByPages(feed.videoIds),
  };
}

// ---------- Source 2: YouTube Data API v3 (used only when the RSS path fails and YOUTUBE_API_KEY is set) ----------

const API_BASE = "https://www.googleapis.com/youtube/v3";
let apiPausedUntil = 0;

const channelsSchema = z.object({
  items: z.array(z.object({ id: z.string().regex(CHANNEL_ID_RE), snippet: z.object({ title: z.string() }) })).default([]),
});
const uploadsSchema = z.object({ items: z.array(z.object({ contentDetails: z.object({ videoId: z.string() }) })).default([]) });
const videosSchema = z.object({
  items: z
    .array(
      z.object({
        id: z.string(),
        snippet: z.object({ title: z.string(), liveBroadcastContent: z.string() }),
        liveStreamingDetails: z.object({ scheduledStartTime: z.string().optional(), actualStartTime: z.string().optional() }).optional(),
      }),
    )
    .default([]),
});

function apiReason(body: string): string {
  try {
    const parsed = z.object({ error: z.object({ errors: z.array(z.object({ reason: z.string() })).min(1) }) }).safeParse(JSON.parse(body));
    return parsed.success ? parsed.data.error.errors[0]!.reason : "";
  } catch {
    return "";
  }
}

// The key travels in a header, never in the URL, so it cannot end up in a proxy log or an error message.
async function apiGet<S extends z.ZodType>(path: string, params: Record<string, string>, schema: S): Promise<z.output<S>> {
  if (Date.now() < apiPausedUntil) throw new Error("YouTube API quota is used up, API checks are paused");
  const res = await ytFetch(`${API_BASE}/${path}?${new URLSearchParams(params)}`, {
    headers: { "x-goog-api-key": YOUTUBE_API_KEY },
    timeoutMs: REQUEST_TIMEOUT_MS,
  });
  const body = await readBounded(res, MAX_API_BYTES);
  if (!res.ok) {
    const reason = apiReason(body);
    if (/quota|dailyLimit|rateLimit/i.test(reason)) {
      apiPausedUntil = Date.now() + API_PAUSE_MS;
      audit("warn", "api.quota", "YouTube API quota is used up. API checks are paused for 1 hour.");
    }
    throw new ApiError(res.status, reason);
  }
  const parsed = schema.safeParse(JSON.parse(body));
  if (!parsed.success) throw new Error("YouTube API sent an unexpected response");
  return parsed.data;
}

async function resolveByApi(handle: string): Promise<{ id: string; name: string }> {
  const { items } = await apiGet("channels", { part: "snippet", forHandle: handle }, channelsSchema);
  const channel = items[0];
  if (!channel) throw new NotFoundError("Channel not found");
  return { id: channel.id, name: channel.snippet.title };
}

async function recentUploads(channelId: string): Promise<string[]> {
  try {
    const { items } = await apiGet(
      "playlistItems",
      { part: "contentDetails", playlistId: `UU${channelId.slice(2)}`, maxResults: String(MAX_CANDIDATES) },
      uploadsSchema,
    );
    return items.map((item) => item.contentDetails.videoId);
  } catch (err) {
    if (err instanceof ApiError && err.reason === "playlistNotFound") return [];
    throw err;
  }
}

async function classifyByApi(videoIds: string[]): Promise<Stream[]> {
  const streams: Stream[] = [];
  const unknown: string[] = [];
  for (const id of videoIds) {
    const hit = cached(id);
    if (!hit.known) unknown.push(id);
    else if (hit.stream) streams.push(hit.stream);
  }
  if (unknown.length === 0) return streams;
  const { items } = await apiGet("videos", { part: "snippet,liveStreamingDetails", id: unknown.join(",") }, videosSchema);
  const byId = new Map(items.map((item) => [item.id, item]));
  for (const id of unknown) {
    const item = byId.get(id);
    const status = item?.snippet.liveBroadcastContent;
    if (!item || (status !== "live" && status !== "upcoming")) {
      remember(id, null);
      continue;
    }
    const details = item.liveStreamingDetails;
    const stream: Stream = {
      videoId: id,
      title: item.snippet.title || "Untitled stream",
      status,
      startAt: toUnix(status === "live" ? (details?.actualStartTime ?? details?.scheduledStartTime) : (details?.scheduledStartTime ?? details?.actualStartTime)),
    };
    remember(id, stream);
    streams.push(stream);
  }
  return streams;
}

async function viaApi(channel: ChannelRef): Promise<Lookup> {
  const identity = channel.youtubeId ? { id: channel.youtubeId, name: channel.name ?? channel.handle } : await resolveByApi(channel.handle);
  return {
    channelId: identity.id,
    channelName: identity.name,
    source: "api",
    streams: await classifyByApi(await recentUploads(identity.id)),
  };
}

export async function lookupStreams(channel: ChannelRef): Promise<Lookup> {
  try {
    return await viaRss(channel);
  } catch (rssError) {
    if (!YOUTUBE_API_KEY || rssError instanceof NotFoundError) throw rssError;
    try {
      return await viaApi(channel);
    } catch (apiError) {
      throw new Error(`RSS: ${errorMessage(rssError)}. API: ${errorMessage(apiError)}`);
    }
  }
}

// maxresdefault does not exist for every video (YouTube answers 404, which Discord shows as an empty embed).
// A HEAD request reads headers only, so no image bytes are downloaded; on 404 fall back to hqdefault.
const thumbnails = new Map<string, string>();

export async function thumbnailFor(videoId: string): Promise<string> {
  const cachedUrl = thumbnails.get(videoId);
  if (cachedUrl) return cachedUrl;
  const max = `https://i.ytimg.com/vi/${videoId}/maxresdefault.jpg`;
  try {
    const res = await ytFetch(max, { method: "HEAD", redirect: "error", timeoutMs: 4000 });
    if (res.ok || res.status === 404) {
      const url = res.ok ? max : `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`;
      if (thumbnails.size >= 200) thumbnails.delete(thumbnails.keys().next().value!);
      thumbnails.set(videoId, url);
      return url;
    }
  } catch {
    // Network hiccup: not cached, the next send probes again.
  }
  return max;
}
